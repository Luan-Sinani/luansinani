# Trivia API

Trivia is a Questions and Answers application

###### [Backend README](backend/README.md)
###### [Frontend README](frontend/README.md)